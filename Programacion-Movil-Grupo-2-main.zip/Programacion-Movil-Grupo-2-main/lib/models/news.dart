class News {
  final int id;
  final String title;
  final String summary;
  final String content;
  final String image;
  final String category;
  final String date;

  News({
    required this.id,
    required this.title,
    required this.summary,
    required this.content,
    required this.image,
    required this.category,
    required this.date,
  });

  factory News.fromJson(
    Map<String, dynamic> json,
  ) {
    return News(
      id: json['id'] as int,
      title: json['title'] as String,
      summary: json['summary'] as String,
      content: json['content'] as String,
      image: json['image'] as String,
      category: json['category'] as String,
      date: json['date'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'summary': summary,
      'content': content,
      'image': image,
      'category': category,
      'date': date,
    };
  }

  @override
  String toString() {
    return '''
News(
  id: $id,
  title: $title,
  category: $category,
  date: $date
)
''';
  }
}