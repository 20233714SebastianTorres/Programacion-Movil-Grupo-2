class Director {

  final String name;
  final int movieCount;
  final double averageRating;

  Director({
    required this.name,
    required this.movieCount,
    required this.averageRating,
  });

  factory Director.fromJson(Map<String, dynamic> json) {

    return Director(

      name: json["director"],

      movieCount: json["movie_count"],

      averageRating:
          (json["average_rating"] as num).toDouble(),

    );

  }

}