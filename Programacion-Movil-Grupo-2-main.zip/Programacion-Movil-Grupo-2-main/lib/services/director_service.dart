import 'dart:convert';

import 'package:http/http.dart' as http;

import '../configs/api.dart';
import '../configs/generic_response.dart';
import '../models/director.dart';

class DirectorService {

  Future<GenericResponse> fetchFeaturedDirectors() async {

    try {

      final response = await http.get(
        Uri.parse(
          "${ApiConfig.baseUrl}/apis/v6/directors",
        ),
      );

      final body =
          json.decode(response.body);

      final directors =
          (body["data"] as List)
              .map(
                (e) => Director.fromJson(e),
              )
              .toList();

      return GenericResponse(
        success: true,
        data: directors,
        message: body["message"],
        error: null,
      );

    } catch (e) {

      return GenericResponse(
        success: false,
        data: null,
        message: "Error",
        error: e.toString(),
      );

    }

  }

}