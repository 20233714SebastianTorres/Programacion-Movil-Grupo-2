import 'dart:convert';

import 'package:flutter/services.dart';

import '../configs/generic_response.dart';
import '../models/news.dart';

class NewsService {
  Future<GenericResponse> fetchAll() async {
    try {
      String jsonString = await rootBundle.loadString(
        'assets/jsons/news.json',
      );

      final List<dynamic> jsonList = json.decode(jsonString);

      final List<News> news = jsonList
          .map(
            (json) => News.fromJson(json),
          )
          .toList();

      return GenericResponse(
        success: true,
        data: news,
        message: 'Noticias obtenidas correctamente',
        error: null,
      );
    } catch (e, stackTrace) {
      print('Error: $e');
      print('Stack Trace: $stackTrace');

      return GenericResponse(
        success: false,
        data: null,
        message: 'Ocurrió un error al obtener noticias',
        error: stackTrace.toString(),
      );
    }
  }
}