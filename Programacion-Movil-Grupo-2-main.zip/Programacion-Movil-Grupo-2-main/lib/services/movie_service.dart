// lib/services/movie_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;

import '../configs/api.dart';
import '../configs/generic_response.dart';
import '../models/movie.dart';

class MovieService {
  Future<GenericResponse> _fetchMovies(String endpoint) async {
    try {
      final response = await http.get(
        /// TEMPORAL
        print("GET -> ${ApiConfig.baseUrl}$endpoint");
        print("Status: ${response.statusCode}");
        print(response.body);
        Uri.parse("${ApiConfig.baseUrl}$endpoint"),
      );

      if (response.statusCode != 200) {
        return GenericResponse(
          success: false,
          data: null,
          message: "Error del servidor",
          error: response.body,
        );
      }

      final Map<String, dynamic> body = json.decode(response.body);

      final List<Movie> movies = (body["data"] as List)
          .map(
            (e) => Movie.fromJson(e),
          )
          .toList();

      return GenericResponse(
        success: true,
        data: movies,
        message: body["message"],
        error: null,
      );
    } catch (e, stackTrace) {
      return GenericResponse(
        success: false,
        data: null,
        message: "Ocurrió un error",
        error: stackTrace.toString(),
      );
    }
  }

  Future<GenericResponse> fetchAll() async {
    return _fetchMovies("/apis/v1/movies");
  }

  Future<GenericResponse> searchByGenre(String genre) async {
    return _fetchMovies("/apis/v2/movies?genre=$genre");
  }

  Future<GenericResponse> searchByTitle(String title) async {
    return _fetchMovies("/apis/v3/movies?title=$title");
  }

  Future<GenericResponse> fetchPopularMovies() async {
    return _fetchMovies("/apis/v5/movies");
  }

  Future<GenericResponse> fetchUpcomingMovies() async {
    return _fetchMovies("/apis/v7/movies/upcoming");
  }
}