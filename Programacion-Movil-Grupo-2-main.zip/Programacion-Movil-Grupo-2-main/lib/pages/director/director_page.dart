import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../models/director.dart';
import 'director_controller.dart';

class DirectorPage extends StatelessWidget {

  DirectorPage({super.key});

  final DirectorController control =
      Get.put(DirectorController());

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: const Color(0xFF020617),

      appBar: AppBar(

        backgroundColor: const Color(0xFF111827),

        centerTitle: true,

        title: const Text(
          "Directores Destacados",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),

      ),

      body: Obx(() {

        if (control.isLoading.value) {

          return const Center(
            child: CircularProgressIndicator(),
          );

        }

        return ListView.builder(

          padding: const EdgeInsets.all(20),

          itemCount: control.directors.length,

          itemBuilder: (_, index) {

            final Director director =
                control.directors[index];

            return _directorCard(director);

          },

        );

      }),

    );

  }

  Widget _directorCard(Director director) {

    return Container(

      margin: const EdgeInsets.only(
        bottom: 20,
      ),

      padding: const EdgeInsets.all(20),

      decoration: BoxDecoration(

        color: const Color(0xFF111827),

        borderRadius:
            BorderRadius.circular(24),

        border: Border.all(
          color: Colors.white10,
        ),

      ),

      child: Column(

        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [

          Text(

            director.name,

            style: const TextStyle(

              color: Colors.white,

              fontWeight: FontWeight.bold,

              fontSize: 22,

            ),

          ),

          const SizedBox(height: 18),

          Row(

            children: [

              const Icon(
                Icons.movie,
                color: Colors.deepPurpleAccent,
              ),

              const SizedBox(width: 10),

              Text(

                "${director.movieCount} películas",

                style: const TextStyle(
                  color: Colors.white70,
                ),

              ),

            ],

          ),

          const SizedBox(height: 10),

          Row(

            children: [

              const Icon(
                Icons.star,
                color: Colors.amber,
              ),

              const SizedBox(width: 10),

              Text(

                director.averageRating
                    .toString(),

                style: const TextStyle(
                  color: Colors.white70,
                ),

              ),

            ],

          ),

        ],

      ),

    );

  }

}