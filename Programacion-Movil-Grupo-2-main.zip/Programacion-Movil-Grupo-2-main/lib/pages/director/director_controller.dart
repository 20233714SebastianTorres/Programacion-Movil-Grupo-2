import 'package:get/get.dart';

import '../../models/director.dart';
import '../../services/director_service.dart';

class DirectorController extends GetxController {

  final DirectorService _service = DirectorService();

  RxList<Director> directors = <Director>[].obs;

  RxBool isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    fetchDirectors();
  }

  Future<void> fetchDirectors() async {

    isLoading.value = true;

    final response =
        await _service.fetchFeaturedDirectors();

    if (response.success) {
      directors.value =
          response.data as List<Director>;
    }

    isLoading.value = false;
  }

}