import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'news_controller.dart';

class NewsPage extends StatelessWidget {
  const NewsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(NewsController());

    return Scaffold(
      backgroundColor: const Color(0xFF020617),

      appBar: AppBar(
        title: const Text('Noticias'),
        backgroundColor: const Color(0xFF111827),
      ),

      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(
            child: CircularProgressIndicator(
              color: Color(0xFF8B5CF6),
            ),
          );
        }

        if (controller.news.isEmpty) {
          return const Center(
            child: Text(
              'No hay noticias disponibles',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 18,
              ),
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(12),

          itemCount: controller.news.length,

          itemBuilder: (context, index) {
            final news = controller.news[index];

            return Container(
              margin: const EdgeInsets.only(
                bottom: 14,
              ),

              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: Colors.white10,
                ),
              ),

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [

                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(16),
                    ),

                    child: Image.network(
                      news.image,
                      height: 180,
                      width: double.infinity,
                      fit: BoxFit.cover,

                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          height: 180,
                          color: Colors.black26,
                          child: const Center(
                            child: Icon(
                              Icons.image_not_supported,
                              color: Colors.white54,
                              size: 40,
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(14),

                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [

                        Text(
                          news.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        const SizedBox(height: 8),

                        Text(
                          news.summary,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,

                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 14,
                          ),
                        ),

                        const SizedBox(height: 10),

                        Row(
                          children: [

                            Text(
                              news.category,
                              style: const TextStyle(
                                color: Color(0xFF8B5CF6),
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            const Spacer(),

                            Text(
                              news.date,
                              style: const TextStyle(
                                color: Colors.white54,
                              ),
                            ),

                          ],
                        ),

                      ],
                    ),
                  ),

                ],
              ),
            );
          },
        );
      }),
    );
  }
}