import 'package:get/get.dart';

import '../../models/news.dart';
import '../../services/news_service.dart';

class NewsController extends GetxController {
  final NewsService _newsService = NewsService();

  RxList<News> news = <News>[].obs;

  RxBool isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();

    fetchNews();
  }

  Future<void> fetchNews() async {
    isLoading.value = true;

    final response = await _newsService.fetchAll();

    if (response.success) {
      news.value = response.data as List<News>;
    }

    isLoading.value = false;
  }
}