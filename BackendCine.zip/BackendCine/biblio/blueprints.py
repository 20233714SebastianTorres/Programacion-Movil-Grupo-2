from .apis.genre import api as api_genres
from .apis.publisher import api as api_publishers
from .apis.book import api as api_books
from .apis.user import api as api_users

blueprints = [
  api_genres,
  api_publishers,
  api_books,
  api_users,
]