# biblio\apis\publisher.py
import traceback
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required
from main.models import User
from biblio.models import Publisher
from main.database import Session

api = Blueprint('biblio_apis_publishers', __name__)

@api.route('/apis/v1/publishers', methods=['GET'])
#@jwt_required()
def fetch_all():
  # data
  response = None
  status = 200
  # blogic
  session = Session()
  try:
    publishers = session.query(Publisher).all()
    publishers_list = [publisher.to_dict() for publisher in publishers]
    response = jsonify({
      'message': 'lista de editoariales',
      'data': publishers_list, 
      'success': True,
      'error': None
    })
  except Exception as e:
    traceback.print_exc()
    response = jsonify({
      'message': 'Ocurrió un error en lista los editoriales',
      'error': str(e),
      'data': None,
      'success': False
    })
    status = 500
  finally:
    session.close()
  # response
  return response, status

@api.route('/apis/v1/publishers/<int:id>', methods=['GET'])
#@jwt_required()
def fetch_by_id(id):
  # data
  response = None
  status = 200
  
  # blogic
  session = Session()
  try:
    # Buscamos el género por su ID
    publisher = session.query(Publisher).get(id)
    
    if publisher:
      response = jsonify({
        'message': 'Editorial encontrada',
        'data': publisher.to_dict(), 
        'success': True,
        'error': None
      })
    else:
      response = jsonify({
        'message': f'No se encontró la editorial con ID {id}',
        'data': None,
        'success': False,
        'error': 'Not Found'
      })
      status = 404
      
  except Exception as e:
    traceback.print_exc()
    response = jsonify({
      'message': 'Ocurrió un error al buscar el género',
      'error': str(e),
      'data': None,
      'success': False
    })
    status = 500
  finally:
    session.close()
    
  # response
  return response, status