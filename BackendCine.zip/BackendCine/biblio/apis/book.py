# biblio\apis\book.py
import traceback
from flask import Blueprint, jsonify, request, g
from main.middlewares import jwt_required
from main.models import User
from biblio.models import Book, Genre
from main.database import Session
from sqlalchemy.orm import joinedload, selectinload

api = Blueprint('biblio_apis_books', __name__)

@api.route('/apis/v3/books', methods=['GET'])
#@jwt_required()
def fetch_all():
  # data
  response = None
  status = 200
  # blogic
  session = Session()
  try:
    books = session.query(Book).all()
    books_list = [book.to_dict() for book in books]
    response = jsonify({
      'message': 'lista de libros',
      'data': books_list, 
      'success': True,
      'error': None
    })
  except Exception as e:
    traceback.print_exc()
    response = jsonify({
      'message': 'Ocurrió un error en lista los libros',
      'error': str(e),
      'data': None,
      'success': False
    })
    status = 500
  finally:
    session.close()
  # response
  return response, status

@api.route('/apis/v1/books', methods=['GET'])
@jwt_required
def fetch_all_search():
    response = None
    status = 200

    session = Session()
    
    print('1 ++++++++++++++++++++++++++++++++')
    print(g.user_id)
    print(g.username)  
    print('2 ++++++++++++++++++++++++++++++++')

    try:
        query = session.query(Book)

        genres_param = request.args.get('genres')

        if genres_param:
            genre_ids = [
                int(id.strip())
                for id in genres_param.split(',')
                if id.strip().isdigit()
            ]

            if genre_ids:
                query = (
                    query
                    .join(Book.genres)
                    .filter(Genre.id.in_(genre_ids))
                    .distinct()
                )

        books = query.all()

        response = jsonify({
            'message': 'lista de libros',
            'data': [book.to_dict() for book in books],
            'success': True,
            'error': None
        })

    except Exception as e:
        traceback.print_exc()

        response = jsonify({
            'message': 'Ocurrió un error al listar los libros',
            'error': str(e),
            'data': None,
            'success': False
        })
        status = 500

    finally:
        session.close()

    return response, status

@api.route('/apis/v2/books', methods=['GET'])
#@jwt_required()
def fetch_all_join():
  # data
  response = None
  status = 200
  
  # blogic
  session = Session()
  try:
    # Optimizamos la consulta cargando de antemano las relaciones necesarias
    books = (
      session.query(Book)
      .options(
        joinedload(Book.publisher),       # Carga la relación 1 a Muchos (Publisher)
        selectinload(Book.genres),       # Carga la relación Muchos a Muchos (Genres)
        selectinload(Book.authors)       # Carga la relación Muchos a Muchos (Authors)
      )
      .all()
    )
    
    # Al procesar el to_dict(), SQLAlchemy ya tendrá todos los datos listos en memoria
    books_list = [book.to_dict() for book in books]
    
    response = jsonify({
      'message': 'lista de libros',
      'data': books_list, 
      'success': True,
      'error': None
    })
  except Exception as e:
    traceback.print_exc()
    response = jsonify({
      'message': 'Ocurrió un error en lista los libros',
      'error': str(e),
      'data': None,
      'success': False
    })
    status = 500
  finally:
    session.close()
    
  # response
  return response, status