# biblio\apis\genre.py
import traceback
from flask import Blueprint, jsonify, request
from flask_jwt_extended import jwt_required
from main.models import User
from biblio.models import Genre
from main.database import Session

api = Blueprint('biblio_apis_genres', __name__)

@api.route('/apis/v1/genres', methods=['GET'])
#@jwt_required()
def fetch_all():
  # data
  response = None
  status = 200
  # blogic
  session = Session()
  try:
    genres = session.query(Genre).all()
    genres_list = [genre.to_dict() for genre in genres]
    response = jsonify({
      'message': 'lista de géneros',
      'data': genres_list, 
      'success': True,
      'error': None
    })
  except Exception as e:
    traceback.print_exc()
    response = jsonify({
      'message': 'Ocurrió un error en lista los géneros',
      'error': str(e),
      'data': None,
      'success': False
    })
    status = 500
  finally:
    session.close()
  # response
  return response, status

@api.route('/apis/v1/genres/<int:id>', methods=['GET'])
#@jwt_required()
def fetch_by_id(id):
  # data
  response = None
  status = 200
  
  # blogic
  session = Session()
  try:
    # Buscamos el género por su ID
    genre = session.query(Genre).get(id)
    
    if genre:
      response = jsonify({
        'message': 'Género encontrado',
        'data': genre.to_dict(), 
        'success': True,
        'error': None
      })
    else:
      response = jsonify({
        'message': f'No se encontró el género con ID {id}',
        'data': None,
        'success': False,
        'error': 'Not Found'
      })
      status = 404
      
  except Exception as e:
    traceback.print_exc()
    response = jsonify({
      'message': 'Ocurrió un error al buscar el género',
      'error': str(e),
      'data': None,
      'success': False
    })
    status = 500
  finally:
    session.close()
    
  # response
  return response, status

@api.route('/apis/v1/genres', methods=['POST'])
#@jwt_required()
def create_genre():
  # data
  response = None
  status = 201  # HTTP 201 Created es el ideal para respuestas POST exitosas
  
  # Obtener los datos del cuerpo de la petición (JSON)
  data = request.get_json()
  
  if not data or 'name' not in data or not data['name'].strip():
    return jsonify({
      'message': 'El campo "name" es obligatorio.',
      'data': None,
      'success': False,
      'error': 'Missing required fields'
    }), 400

  # blogic
  session = Session()
  try:
    # Crear la nueva instancia del modelo Genre
    new_genre = Genre(name=data['name'].strip())
    
    # Agregar y guardar en la base de datos
    session.add(new_genre) # INSERT INTO genres (name) VALUES (?);
    session.commit() 
    
    # Construir la respuesta con el género creado (incluyendo su ID generado)
    response = jsonify({
      'message': 'Género creado exitosamente',
      'data': new_genre.to_dict(),
      'success': True,
      'error': None
    })
  except Exception as e:
    session.rollback() # Buena práctica: revertir cambios si algo falla antes de cerrar
    traceback.print_exc()
    response = jsonify({
      'message': 'Ocurrió un error al crear el género',
      'error': str(e),
      'data': None,
      'success': False
    })
    status = 500
  finally:
    session.close()
    
  # response
  return response, status

@api.route('/apis/v1/genres/<int:genre_id>', methods=['DELETE'])
#@jwt_required()
def delete_genre(genre_id):
  # data
  response = None
  status = 200
  
  # blogic
  session = Session()
  try:
    # Buscar el género por su ID
    genre = session.query(Genre).filter(Genre.id == genre_id).first()
    # SELECT * FROM genres WHERE id = ? LIMIT 1
    
    # Si no existe, retornar un 404 Not Found
    if not genre:
      return jsonify({
        'message': f'No se encontró el género con ID {genre_id}',
        'data': None,
        'success': False,
        'error': 'Not Found'
      }), 404
      
    # Eliminar el registro
    session.delete(genre)
    # DELETE FROM genres WHERE id = ?
    session.commit()
    
    response = jsonify({
      'message': 'Género eliminado exitosamente',
      'data': {'id': genre_id}, # Devolvemos el ID eliminado como confirmación
      'success': True,
      'error': None
    })
  except Exception as e:
    session.rollback() # Revertir cambios en caso de error
    traceback.print_exc()
    response = jsonify({
      'message': 'Ocurrió un error al eliminar el género',
      'error': str(e),
      'data': None,
      'success': False
    })
    status = 500
  finally:
    session.close()
    
  # response
  return response, status

@api.route('/apis/v1/genres/<int:genre_id>', methods=['PUT'])
#@jwt_required()
def update_genre(genre_id):
  # data
  response = None
  status = 200
  
  # Obtener los datos del cuerpo de la petición (JSON)
  data = request.get_json()
  
  if not data or 'name' not in data or not data['name'].strip():
    return jsonify({
      'message': 'El campo "name" es obligatorio para actualizar.',
      'data': None,
      'success': False,
      'error': 'Missing required fields'
    }), 400

  # blogic
  session = Session()
  try:
    # Buscar el género existente por su ID
    genre = session.query(Genre).filter(Genre.id == genre_id).first()
    # SELECT * FROM genres WHERE id = ? LIMIT 1
    
    # Si no existe, retornar un 404 Not Found
    if not genre:
      return jsonify({
        'message': f'No se encontró el género con ID {genre_id}',
        'data': None,
        'success': False,
        'error': 'Not Found'
      }), 404
      
    # Actualizar el campo
    genre.name = data['name'].strip()
    # UPDATE genres SET name = ? WHERE id = ?
    session.commit()
    
    # Construir la respuesta con el género actualizado
    response = jsonify({
      'message': 'Género actualizado exitosamente',
      'data': genre.to_dict(),
      'success': True,
      'error': None
    })
  except Exception as e:
    session.rollback() # Revertir cambios en caso de error
    traceback.print_exc()
    response = jsonify({
      'message': 'Ocurrió un error al actualizar el género',
      'error': str(e),
      'data': None,
      'success': False
    })
    status = 500
  finally:
    session.close()
    
  # response
  return response, status