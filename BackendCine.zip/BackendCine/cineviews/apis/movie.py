# cineviews/apis/movie.py

import traceback

from flask import Blueprint, jsonify, request
from sqlalchemy.orm import selectinload

from main.database import Session
from main.middlewares import jwt_required

from datetime import datetime

from cineviews.models import Movie, Review, WatchedMovie

api = Blueprint('cineviews_apis_movies', __name__)


# =====================================================
# LISTAR TODAS LAS PELÍCULAS
# =====================================================

@api.route('/apis/v1/movies', methods=['GET'])
# @jwt_required
def fetch_all():

    response = None
    status = 200

    session = Session()

    try:

        movies = session.query(Movie).all()

        response = jsonify({
            'message': 'Lista de películas',
            'data': [movie.to_dict() for movie in movies],
            'success': True,
            'error': None
        })

    except Exception as e:

        traceback.print_exc()

        response = jsonify({
            'message': 'Ocurrió un error al listar películas',
            'data': None,
            'success': False,
            'error': str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status


# =====================================================
# BUSCAR POR GÉNERO
# =====================================================

@api.route('/apis/v2/movies', methods=['GET'])
# @jwt_required
def search_by_genre():

    response = None
    status = 200

    session = Session()

    try:

        query = session.query(Movie)

        genre = request.args.get('genre')

        if genre:
            query = query.filter(
                Movie.genre.ilike(f'%{genre}%')
            )

        movies = query.all()

        response = jsonify({
            'message': 'Películas filtradas correctamente',
            'data': [movie.to_dict() for movie in movies],
            'success': True,
            'error': None
        })

    except Exception as e:

        traceback.print_exc()

        response = jsonify({
            'message': 'Ocurrió un error al filtrar películas',
            'data': None,
            'success': False,
            'error': str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status


# =====================================================
# BUSCAR POR TÍTULO
# =====================================================

@api.route('/apis/v3/movies', methods=['GET'])
# @jwt_required
def search_by_title():

    response = None
    status = 200

    session = Session()

    try:

        query = session.query(Movie)

        title = request.args.get('title')

        if title:
            query = query.filter(
                Movie.title.ilike(f'%{title}%')
            )

        movies = query.all()

        response = jsonify({
            'message': 'Películas encontradas correctamente',
            'data': [movie.to_dict() for movie in movies],
            'success': True,
            'error': None
        })

    except Exception as e:

        traceback.print_exc()

        response = jsonify({
            'message': 'Ocurrió un error al buscar películas',
            'data': None,
            'success': False,
            'error': str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status

# =====================================================
# LISTAR TODAS LAS PELÍCULAS EN FAVORITOS
# =====================================================
@api.route('/apis/v1/favorites/<int:user_id>', methods=['GET'])
# @jwt_required
def fetch_favorites(user_id):

    response = None
    status = 200

    session = Session()

    try:

        movies = (
            session.query(Movie)
            .join(Movie.watched_by)
            .filter(
                WatchedMovie.user_id == user_id,
                WatchedMovie.favorite == True
            )
            .all()
        )

        response = jsonify({
            'message': 'Lista de películas favoritas',
            'data': [movie.to_dict() for movie in movies],
            'success': True,
            'error': None
        })

    except Exception as e:

        traceback.print_exc()

        response = jsonify({
            'message': 'Ocurrió un error al listar favoritos',
            'data': None,
            'success': False,
            'error': str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status


# =====================================================
# AGREGAR PELÍCULA A FAVORITOS
# =====================================================

@api.route('/apis/v1/favorites', methods=['POST'])
# @jwt_required
def add_favorite():

    response = None
    status = 200

    session = Session()

    try:

        data = request.json

        watched = (
            session.query(WatchedMovie)
            .filter(
                WatchedMovie.user_id == data["user_id"],
                WatchedMovie.movie_id == data["movie_id"]
            )
            .first()
        )

        if watched is None:

            return jsonify({
                "message": "La película no ha sido vista por el usuario",
                "data": None,
                "success": False,
                "error": None
            }), 404

        watched.favorite = True

        session.commit()

        response = jsonify({
            "message": "Película agregada a favoritos",
            "data": watched.to_dict(),
            "success": True,
            "error": None
        })

    except Exception as e:

        session.rollback()
        traceback.print_exc()

        response = jsonify({
            "message": "Ocurrió un error al agregar a favoritos",
            "data": None,
            "success": False,
            "error": str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status

# =====================================================
# LISTAR PELÍCULAS CON REVIEWS
# =====================================================

@api.route('/apis/v4/movies', methods=['GET'])
# @jwt_required
def fetch_all_join():

    response = None
    status = 200

    session = Session()

    try:

        movies = (
            session.query(Movie)
            .options(
                selectinload(Movie.reviews)
            )
            .all()
        )

        response = jsonify({
            'message': 'Lista de películas con reviews',
            'data': [movie.to_dict() for movie in movies],
            'success': True,
            'error': None
        })

    except Exception as e:

        traceback.print_exc()

        response = jsonify({
            'message': 'Ocurrió un error al listar películas',
            'data': None,
            'success': False,
            'error': str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status


@api.route('/apis/v5/movies', methods=['GET'])
@api.route('/apis/v5/movies', methods=['GET'])
def fetch_popular_movies():

    response = None
    status = 200

    session = Session()

    try:

        movies = (
            session.query(Movie)
            .options(
                selectinload(Movie.reviews),
                selectinload(Movie.watched_by)
            )
            .all()
        )

        data = []

        for movie in movies:

            review_count = len(movie.reviews)

            favorite_count = sum(
                1
                for watched in movie.watched_by
                if watched.favorite
            )

            popularity_score = round(
                movie.average_rating * 2 +
                review_count +
                favorite_count,
                2
            )

            item = movie.to_dict()

            item["review_count"] = review_count
            item["favorite_count"] = favorite_count
            item["popularity_score"] = popularity_score

            data.append(item)

        # Ordenar de mayor a menor popularidad
        data.sort(
            key=lambda x: x["popularity_score"],
            reverse=True
        )

        # Conservar únicamente las 10 primeras
        data = data[:10]

        response = jsonify({
            "message": "Películas populares",
            "data": data,
            "success": True,
            "error": None
        })

    except Exception as e:

        traceback.print_exc()

        response = jsonify({
            "message": "Error al obtener películas populares",
            "data": None,
            "success": False,
            "error": str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status


# =====================================================
# DIRECTORES DESTACADOS
# =====================================================

@api.route('/apis/v6/directors', methods=['GET'])
def fetch_featured_directors():

    response = None
    status = 200

    session = Session()

    try:

        directors = (
            session.query(
                Movie.director,
                func.count(Movie.id).label("movie_count"),
                func.avg(Movie.average_rating).label("average_rating")
            )
            .group_by(Movie.director)
            .order_by(func.avg(Movie.average_rating).desc())
            .all()
        )

        data = []

        for director in directors:

            data.append({
                "director": director.director,
                "movie_count": director.movie_count,
                "average_rating": round(float(director.average_rating), 2)
            })

        response = jsonify({
            "message": "Directores destacados",
            "data": data,
            "success": True,
            "error": None
        })

    except Exception as e:

        traceback.print_exc()

        response = jsonify({
            "message": "Error al obtener directores destacados",
            "data": None,
            "success": False,
            "error": str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status

# =====================================================
# PELÍCULAS PRÓXIMAMENTE
# =====================================================

@api.route('/apis/v7/movies/upcoming', methods=['GET'])
def fetch_upcoming_movies():

    response = None
    status = 200

    session = Session()

    try:

        current_year = request.args.get(
            "year",
            default=datetime.now().year,
            type=int
        )

        movies = (
            session.query(Movie)
            .filter(Movie.year >= current_year)
            .order_by(Movie.year.asc())
            .all()
        )

        response = jsonify({
            "message": "Películas próximas a estrenarse",
            "data": [movie.to_dict() for movie in movies],
            "success": True,
            "error": None
        })

    except Exception as e:

        traceback.print_exc()

        response = jsonify({
            "message": "Error al obtener próximas películas",
            "data": None,
            "success": False,
            "error": str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status

# =====================================================
# DETALLE DE UNA PELÍCULA
# =====================================================

@api.route('/apis/v1/movies/<int:movie_id>', methods=['GET'])
# @jwt_required
def fetch_by_id(movie_id):

    response = None
    status = 200

    session = Session()

    try:

        movie = (
            session.query(Movie)
            .options(
                selectinload(Movie.reviews)
            )
            .filter(
                Movie.id == movie_id
            )
            .first()
        )

        if movie is None:

            return jsonify({
                'message': 'Película no encontrada',
                'data': None,
                'success': False,
                'error': None
            }), 404

        response = jsonify({
            'message': 'Detalle de película',
            'data': movie.to_dict(),
            'success': True,
            'error': None
        })

    except Exception as e:

        traceback.print_exc()

        response = jsonify({
            'message': 'Ocurrió un error al obtener la película',
            'data': None,
            'success': False,
            'error': str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status


# =====================================================
# CREAR REVIEW
# =====================================================

@api.route('/apis/v1/reviews', methods=['POST'])
# @jwt_required
def create_review():

    response = None
    status = 201

    session = Session()

    try:

        data = request.json

        review = Review(
            content=data['content'],
            rating=data['rating'],
            user_id=data['user_id'],
            movie_id=data['movie_id']
        )

        session.add(review)
        session.commit()

        response = jsonify({
            'message': 'Comentario creado correctamente',
            'data': review.to_dict(),
            'success': True,
            'error': None
        })

    except Exception as e:

        session.rollback()

        traceback.print_exc()

        response = jsonify({
            'message': 'Ocurrió un error al crear el comentario',
            'data': None,
            'success': False,
            'error': str(e)
        })

        status = 500

    finally:
        session.close()

    return response, status

