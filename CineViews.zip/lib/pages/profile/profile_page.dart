import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  TextEditingController nameController = TextEditingController(text: "Usuario");

  TextEditingController emailController =
      TextEditingController(text: "usuario@email.com");

  TextEditingController bioController = TextEditingController();

  bool editing = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF020617),
      appBar: AppBar(
        backgroundColor: const Color(0xFF111827),
        title: const Text("Perfil"),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(editing ? Icons.check : Icons.edit),
            onPressed: () {
              setState(() {
                editing = !editing;
              });
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const CircleAvatar(
              radius: 45,
              backgroundColor: Color(0xFF7C3AED),
              child: Icon(
                Icons.person,
                size: 50,
                color: Colors.white,
              ),
            ),

            const SizedBox(height: 20),

            // NOMBRE
            TextField(
              controller: nameController,
              enabled: editing,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: "Nombre",
                labelStyle: TextStyle(color: Colors.white70),
              ),
            ),

            const SizedBox(height: 10),

            // EMAIL
            TextField(
              controller: emailController,
              enabled: editing,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: "Correo",
                labelStyle: TextStyle(color: Colors.white70),
              ),
            ),

            const SizedBox(height: 20),

            // CUADRO DE DESCRIPCIÓN
            TextField(
              controller: bioController,
              maxLines: 3,
              enabled: editing,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Descripción",
                labelStyle: const TextStyle(color: Colors.white70),
                hintText: "Escribe algo sobre ti...",
                hintStyle: const TextStyle(color: Colors.white38),
                filled: true,
                fillColor: const Color(0xFF111827),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
              ),
            ),

            const SizedBox(height: 25),

            // BOTÓN LISTA
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF7C3AED),
                  padding: const EdgeInsets.all(14),
                ),
                onPressed: () {
                  Navigator.pushNamed(context, '/list');
                },
                child: const Text(
                  "Ir a Lista",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),

            const SizedBox(height: 15),

            // BOTÓN COMENTARIOS
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF8B5CF6),
                  padding: const EdgeInsets.all(14),
                ),
                onPressed: () {
                  Navigator.pushNamed(context, '/coments');
                },
                child: const Text(
                  "Ir a Comentarios",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),

            const Spacer(),

            // BOTÓN PELÍCULAS
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  padding: const EdgeInsets.all(14),
                ),
                onPressed: () {
                  Navigator.pushNamed(context, '/movies');
                },
                child: const Text(
                  "Ir a Películas",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
