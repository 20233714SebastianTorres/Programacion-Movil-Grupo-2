import 'package:flutter/material.dart';

class ComentsPage extends StatelessWidget {
  const ComentsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF020617),
      appBar: AppBar(
        title: const Text("Comentarios"),
        backgroundColor: const Color(0xFF111827),
      ),
      body: const Center(
        child: Text(
          "Aquí irán los comentarios",
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}
