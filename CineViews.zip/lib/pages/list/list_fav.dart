import 'package:flutter/material.dart';

class ListFavPage extends StatelessWidget {
  const ListFavPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF020617),
      appBar: AppBar(
        title: const Text("Lista de Favoritos"),
        backgroundColor: const Color(0xFF111827),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Column(
        children: [
          // LISTA
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: const [
                ListTile(
                  leading: Icon(Icons.movie, color: Colors.purpleAccent),
                  title: Text("Interstellar",
                      style: TextStyle(color: Colors.white)),
                  subtitle: Text("Ciencia ficción",
                      style: TextStyle(color: Colors.white54)),
                ),
                ListTile(
                  leading: Icon(Icons.movie, color: Colors.purpleAccent),
                  title:
                      Text("Inception", style: TextStyle(color: Colors.white)),
                  subtitle:
                      Text("Thriller", style: TextStyle(color: Colors.white54)),
                ),
                ListTile(
                  leading: Icon(Icons.movie, color: Colors.purpleAccent),
                  title:
                      Text("Avengers", style: TextStyle(color: Colors.white)),
                  subtitle:
                      Text("Acción", style: TextStyle(color: Colors.white54)),
                ),
              ],
            ),
          ),

          // BOTÓN ABAJO
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF7C3AED),
                  padding: const EdgeInsets.all(14),
                ),
                onPressed: () {
                  Navigator.pushNamed(context, '/movies');
                },
                icon: const Icon(Icons.add, color: Colors.white),
                label: const Text(
                  "Añadir nueva película",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
